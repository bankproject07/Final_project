package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.logger.LoggerClass;
import com.cg.obs.util.DBUtil;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;




public class UserDAOImpl implements IUserDAO {


	static Logger myLogger=LoggerClass.myLogger ;
	
	

	/* ****************************************************************	
		Method Name: registerUser
		Parameters: User,Customer
	    Author:Group 5
	    Date:20/3/2017
	    Method Description: Method to create new net banking account.
	 **************************************************************** */
	@Override
	public int registerUser(Users user, Customer customer) throws UserException {

		int accountId = -1;
		try
		{
			con = DBUtil.getConnection();
			String sequenceuser = "select user_seq.nextVal from dual";
			String accSequence ="select accid_seq.nextVal from dual";
			st= con.createStatement();
			ResultSet res=st.executeQuery(sequenceuser);
			ResultSet res1 =st.executeQuery(accSequence);
			while(res.next()== false || res1.next()==false)
			{
				throw new UserException("Something when wromg while generating data ");
			}
			//user
			int userid = res.getInt(1);
			int accId = res1.getInt(2);
			String loginpass = user.getLoginPassword();
			String transPass = user.getTransPassword();
			String secretQ = user.getSecretQuestion();
			String answer = user.getSecretAns();
			String lock = user.getLockStatus();
			//customer 
			String custname = customer.getCustomer_Name();
			String address = customer.getAddress();
			String mail = customer.getEmail();
			String pancard = customer.getPancard();
			
			//insert query.
			String insertuser="insert into user_table values(?,?,?,?,?,?,?)";
			String insertCust ="insert into customer values(?,?,?,?,?)";
			
			pst=con.prepareStatement(insertuser);
			pst.setInt(1, userid);
			pst.setInt(2, accId);
			pst.setString(3, loginpass);
			pst.setString(4, secretQ);
			pst.setString(5, sequenceuser);
			pst.setString(6, transPass);
			pst.setString(7, lock);
			pst.executeQuery();
			
			pst= con.prepareStatement(insertCust);
			pst.setInt(1, accId);
			pst.setString(2, custname);
			pst.setString(3, mail);
			pst.setString(4, address);
			pst.setString(5, pancard);
			pst.executeQuery();
			
			accountId=accId;
			myLogger.info(" Registration Successfull ");
			
		}
		catch (SQLException e)
		{
			myLogger.error("Error occured while adding data"+e.getMessage());
			throw new UserException("Error occured while adding data : reason "+e.getMessage());
			
		}
		
		return accountId;
	}


	/* ****************************************************************	
	Method Name: addRequest
	Parameters: RequestTable
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to request new account from admin for 
    existing customer.
    **************************************************************** */
	
	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		int acc = -1;
		try 
		{
			con = DBUtil.getConnection();
			String cust_seq = "select accid_seq.nextVal from dual";
			Statement st= con.createStatement();
			ResultSet res=st.executeQuery(cust_seq);
				System.out.println(cust_seq);
			while(res.next()==false)
			{
				throw new UserException("Something when wromg while generating id ");
			}
			System.out.println("123456");
			int accID = res.getInt(1);
		
			System.out.println(accID);
			int cust_id = resTab.getCustId();
			String type=resTab.getType();
			
			System.out.println("123");
			
			String insertReq = "insert into requesttable values(?,?,?)";
			System.out.println(insertReq);
			pst=con.prepareStatement(insertReq);
			System.out.println(pst);
			pst.setInt(1, cust_id);
			pst.setString(2, type);
			pst.setInt(3, accID);
			pst.executeQuery();
			
			acc = accID;
			myLogger.info(" Request added for   "+acc);
		}
		catch (SQLException e) 
		{
			myLogger.error("Error occured while adding request:"+e.getMessage());
			throw new UserException("Unable to add Details in Request Table  " + e.getMessage());
		}
		return acc;
	}
	
	
	
	
	/* ****************************************************************	
	Method Name: getAccountId
	Parameters: custId
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to get account Id from new account
    Request Table.
    **************************************************************** */

	@Override
	public RequestTable getAccountId(int custId) throws UserException {
		RequestTable req = new RequestTable();
		
		
		try
		{
			con = DBUtil.getConnection();
			String select = "select * from REQUESTTABLE where customer_ID=?";
			PreparedStatement pst = con.prepareStatement(select);
			pst.setInt(1, custId);
			ResultSet res = pst.executeQuery();
			res.next();
	
			req.setCustId(res.getInt(1));
			req.setType(res.getString(2));
			req.setAcc_id(res.getInt(3));
			myLogger.info(" Getting requested account of customer  ");
		} 
		catch(SQLException e)
		{
			throw new UserException(e.getMessage());
		}
		catch (Exception e) 
		{
			myLogger.error("Error occured while getting data"+e.getMessage());
			throw new UserException(e.getMessage());
		}
		return req;
	}

	PreparedStatement pst;
	Connection con;
	Statement st;
	
	
	
	

	/* ****************************************************************	
	Method Name: getUser
	Parameters: id
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to get user from User Table.
    **************************************************************** */
	
	
	@Override
	public Users getUser(int id) throws UserException {
		
		Users user=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM USER_TABLE WHERE USER_ID=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			rs.next();
			user=new Users();
		
			user.setUserId(rs.getInt(1));
			user.setAccountId(rs.getLong(2));
			user.setLoginPassword(rs.getString(3));
			user.setSecretQuestion(rs.getString(4));
			user.setSecretAns(rs.getString(5));
			user.setTransPassword(rs.getString(6));
			user.setLockStatus(rs.getString(7));
			
			
			myLogger.info(" Login Successfully  ");
			System.out.println(user);
			
		} 
		catch (SQLException e) {
			myLogger.error("Error occured while getting user"+e.getMessage());
			throw new UserException("Problem occured while getting user details"+e.getMessage());
			//e.printStackTrace();
		}
		return user;
	}
	

	/* ****************************************************************	
	Method Name: registerUser
	Parameters: user
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to register new user to User Table.
    **************************************************************** */
	
	@Override
	public void registerUser(Users user) throws UserException {
		
		try{
			con=DBUtil.getConnection();
			String sql="INSERT INTO User_Table VALUES(?,?,?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setInt(1, user.getUserId());	
			pst.setLong(2, user.getAccountId());
			pst.setString(3, user.getLoginPassword());
			pst.setString(4, user.getSecretQuestion());
			pst.setString(5, user.getSecretAns());
			pst.setString(6, user.getTransPassword());
			pst.setString(7, "U");
			
		
			pst.execute();
			myLogger.info(" User registered  Successfully for interenet banking account ");
		}
		catch (SQLException e)
		{
			myLogger.error("Error occured while regestering user:"+e.getMessage());
			throw new UserException("Problem occured while inserting user details"+e.getMessage());
			//e.printStackTrace();
		}
		
	
	}
	
	
	/* ****************************************************************	
	Method Name: getMiniTransactions
	Parameters: accountno
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to get mini transaction record from 
    database.
    **************************************************************** */
	
	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		Transactions transaction=null;
		List<Transactions> transactionList=new ArrayList<Transactions>();
		
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Transaction WHERE Account_ID=? and ROWNUM <= 10";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			while(rs.next())
			{
			transaction=new Transactions();
			transaction.setTransaction_ID(rs.getInt(1));
			transaction.setTran_Description(rs.getString(2));
			transaction.setDateOfTransaction(rs.getDate(3));
			transaction.setTransactionType(rs.getString(4).charAt(0));
			transaction.setTransactionAmount(rs.getDouble(5));
			transaction.setAccountID(rs.getLong(6));
			transactionList.add(transaction);
			
			myLogger.info(" Getting MiniTransaction List ");
			System.out.println(transactionList);
			}
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting transaction details"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			myLogger.error("Error occured while getting Mini Transactions"+e.getMessage());
			throw new UserException("Problem occured while getting transaction details"+e.getMessage());
		}
		return transactionList;
	}
	
	/* ****************************************************************	
	Method Name: getDetailedTransactions
	Parameters: accountno,fromDate,toDate
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to get Detailed transaction record from 
    database.
    **************************************************************** */
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno,Date fromDate,Date toDate) throws UserException {
		
		Transactions transaction=null;
		List<Transactions> transactionList=new ArrayList<Transactions>();
		
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Transaction WHERE Account_ID=? AND DateOfTransaction BETWEEN ? AND ?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			pst.setDate(2, fromDate);
			pst.setDate(3, toDate);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			transaction=new Transactions();
			transaction.setTransaction_ID(rs.getInt(1));
			transaction.setTran_Description(rs.getString(2));
			transaction.setDateOfTransaction(rs.getDate(3));
			transaction.setTransactionType(rs.getString(4).charAt(0));
			transaction.setTransactionAmount(rs.getDouble(5));
			transaction.setAccountID(rs.getLong(6));
			transactionList.add(transaction);
			myLogger.info(" Getting Detailed Transaction List ");
			}
			
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while getting Detailed Transactions"+e.getMessage());
			throw new UserException("Problem occured while getting transaction details"+e.getMessage());
			//e.printStackTrace();
		}
		System.out.println(transactionList);
		return transactionList;
	}
	
	/* ****************************************************************	
	Method Name: getCustomerId
	Parameters: accountno
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to get customer Id from database.
    **************************************************************** */
	
	@Override
	public int getCustomerId(Long accountno) throws UserException {

		int customerid=0;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT Customer_ID FROM Account_Master WHERE Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			rs.next();
			customerid=rs.getInt(1);
			
			System.out.println(customerid);
			myLogger.info(" Getting customer id for accountno:"+accountno);
			
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while getting CustomerId:"+e.getMessage());
			throw new UserException("Problem occured while getting CustomerId"+e.getMessage());
			//e.printStackTrace();
		}
		return customerid;

	
	}
	
	
	/* ****************************************************************	
	Method Name: getCustomer
	Parameters: customerid
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to get customer record from customer
    database.
    **************************************************************** */
	
	
	@Override
	public Customer getCustomer(int customerid) throws UserException {
		Customer customer=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Customer WHERE Customer_ID=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, customerid);
			ResultSet rs=pst.executeQuery();
			System.out.println("res "+rs);
			rs.next();
			customer=new Customer();	
			customer.setCustomer_ID(rs.getInt(1));
			customer.setCustomer_Name(rs.getString(2));
			customer.setEmail(rs.getString(3));
			customer.setMobileNo(rs.getLong(4));
			customer.setAddress(rs.getString(5));
			customer.setPancard(rs.getString(6));
			
			System.out.println(customer);
			myLogger.info(" Getting customer details of customerid: "+customerid);
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while getting Customer:"+e.getMessage());
			throw new UserException("Problem occured while getting user details"+e.getMessage());
			//e.printStackTrace();
		}
		return customer;
		}
	
	
	/* ****************************************************************	
	Method Name: updateCustomerDetails
	Parameters: customer
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to update customer record in database.
    **************************************************************** */
	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
		
		try {
			con=DBUtil.getConnection();
			String sql="UPDATE Customer SET Mobile_No=? , Address=? WHERE Customer_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, customer.getMobileNo());
			pst.setString(2, customer.getAddress());
			pst.setInt(3, customer.getCustomer_ID());
			pst.execute();	
			System.out.println("updated sucess");
			myLogger.info(" Successfully Updated mobile no and address ");
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while updating customer details"+e.getMessage());
			throw new UserException("Problem occured while update customer contact details");
			//e.printStackTrace();
		}
		
	}
	
	/* ****************************************************************	
	Method Name: requestService
	Parameters: services
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to generate cheque book request.
    **************************************************************** */
	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		int requestId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_service_num.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			services.setService_ID(id);
			String insertQuery="INSERT INTO Service_Tracker VALUES(?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setLong(1, id);
			pst.setString(2, services.getService_Description());
			pst.setLong(3, services.getAccount_ID());
			pst.setDate(4 , services.getService_Raised_Date());
			pst.setString(5, services.getService_Status());
			pst.executeUpdate();
			requestId=id;
			myLogger.info("Requested service for requestid "+requestId);
		} catch (SQLException e) {
			
			myLogger.error("Error occured while requesting service:"+e.getMessage());
			throw new UserException("Problem occured while requesting service"+e.getMessage());
			//e.printStackTrace();
		}
		return requestId;
	}
	
	
	
	/* ****************************************************************	
	Method Name: fundTransfer
	Parameters: transferInfo
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to transfer funds across accounts.
    **************************************************************** */
	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		
		int transferId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_fundtransfer_id.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			transferInfo.setFundTransfer_Id(id);
			String insertQuery="INSERT INTO Fund_Transfer VALUES(?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setLong(1, id);
			pst.setLong(2, transferInfo.getAccount_Id());
			pst.setLong(3, transferInfo.getPayee_Account());
			pst.setDate(4 ,transferInfo.getDateOfTransfer());
			pst.setDouble(5, transferInfo.getTransferAmount());
			pst.executeUpdate();
			transferId=id;
			
		} catch (SQLException e) {
			
			myLogger.error("Error occured while performing funds transfer"+e.getMessage());
			throw new UserException("Problem occured while performing funds transfer"+e.getMessage());
			//e.printStackTrace();
		}
		return transferId;
	}
	
	
	/* ****************************************************************	
	Method Name: insertTransaction
	Parameters: transaction
    Author:Group 5
    Date:20/3/2017
    Method Description: Method to insert record in transactions table.
    **************************************************************** */
	@Override
	public void insertTransaction(Transactions transaction)
			throws UserException {
		
		int transactionId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_transactionid.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			transaction.setTransaction_ID(id);
			
		  
			String insertQuery="INSERT INTO Transaction VALUES(?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setInt(1, id);
			pst.setString(2,transaction.getTran_Description());
			pst.setDate(3, transaction.getDateOfTransaction());
			pst.setString(4,String.valueOf(transaction.getTransactionType()));
			pst.setDouble(5, transaction.getTransactionAmount());
			pst.setLong(6, transaction.getAccountID());
			pst.executeUpdate();
		
			myLogger.info("Inserting transaction details");
		} catch (SQLException e) {
			
			myLogger.error("Error occured while performing insert transactions:"+e.getMessage());
			throw new UserException("Problem occured while performing funds transfer"+e.getMessage());
			//e.printStackTrace();
		}
		
	}

	
	/* ****************************************************************	
	Method Name: updateBalance
	Parameters: updatedBalance,accountId
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to update record in account_master table.
    **************************************************************** */
	@Override
	public void updateBalance(double updatedBalance,Long accountId) throws UserException {
		
		try {
			String sql="Update Account_Master set Account_Balance=? where Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setDouble(1, updatedBalance);
			pst.setLong(2, accountId);
			pst.executeQuery();
			myLogger.info(" Updating Balance for accountno"+accountId);
		} catch (SQLException e) {
			
			myLogger.error("Error occured while updated balance:"+e.getMessage());
			throw new UserException("Problem occured while updating balance");

			//e.printStackTrace();
		}
		
	}
	
	/* ****************************************************************	
	Method Name: updatePayeeBalance
	Parameters: user
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to change user password.
    **************************************************************** */	
	@Override
	public void updatePayeeBalance(double Updatedbalance, Long accountNo)
			throws UserException {
		try {
			String sql="Update Account_Master set Account_Balance=? where Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setDouble(1, Updatedbalance);
			pst.setLong(2, accountNo);
			pst.executeQuery();
			myLogger.info(" Updating Balance for accountno"+accountNo);
		} catch (SQLException e) {
			
			myLogger.error("Error occured while updated balance:"+e.getMessage());
			throw new UserException("Problem occured while updating balance");

			//e.printStackTrace();
		}
		
		
	}
	
	
	/* ****************************************************************	
	Method Name: changePassword
	Parameters: user
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to change user password.
    **************************************************************** */	
	@Override
	public void changePassword(Users user) throws UserException {
	
		//int userid=user.getUserId();
		try {
			con=DBUtil.getConnection();
			String updateQuery="Update USER_TABLE set login_password=? where user_id=?";
			pst=con.prepareStatement(updateQuery);
			pst.setString(1, user.getLoginPassword());
			pst.setInt(2, user.getUserId());
			pst.executeUpdate();
			myLogger.info(" Successfully changed password for "+user.getUserId());
		}catch (SQLException e) {
			
			myLogger.error("Error occured while changing password:r"+e.getMessage());
			throw new UserException("Problem occured while changing password"+e.getMessage());
			//e.printStackTrace();
		}	

}
	/* ****************************************************************	
	Method Name: updateLockStatus
	Parameters: userid
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to update account lock status in 
    user_table.
    **************************************************************** */
	@Override
	public void updateLockStatus(int userid) throws UserException {
		
		
		try {
			con=DBUtil.getConnection();
			String updateQuery="Update table User_Table set lock_status=? where user_id=?";
			pst=con.prepareStatement(updateQuery);
			pst.setString(1, "L");
			pst.setInt(2, userid);
			pst.executeUpdate();
		
		}catch (SQLException e) {
			
			myLogger.error("Error occured while updating lock status :"+e.getMessage());
			throw new UserException("Problem occured while updating lock status");
			//e.printStackTrace();
		}	
		
	}
	
	
	/* ****************************************************************	
	Method Name: get payee
	Parameters: accountid
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to get list of payees from 
    payee_table.
    **************************************************************** */
	@Override
	public List<Payee> getPayee(long accountid) throws UserException {
		
		
		Payee payee=null;
		List<Payee> payeeList=new ArrayList<Payee>();
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Payee_Table WHERE ACCOUNT_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountid);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			while(rs.next())
				{
					payee=new Payee();
					payee.setPayeeid(rs.getInt(1));
					payee.setPayeeAccountNo(rs.getLong(2));
					payee.setAccountno(rs.getLong(3));
					payee.setNickName(rs.getString(4));
					payeeList.add(payee);
				}
			
			
			System.out.println(payeeList);
			myLogger.info("Getting payee details  ");
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while getting payee:"+e.getMessage());
			throw new UserException("Problem occured while getting payee details"+e.getMessage());
			//e.printStackTrace();
		}
		return payeeList;
		
	}
	
	
	/* ****************************************************************	
	Method Name: isPayeeAccountExists
	Parameters: payeeAccountNo
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to check if payee account exists.
    **************************************************************** */
	@Override
	public boolean isPayeeAccountExists(long payeeAccountNo)
			throws UserException {
	
		try {
			String sql="select * from Account_Master  where Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, payeeAccountNo);
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
			{
				return true;
			}
			else
			{
			return false;
			}
		} catch (SQLException e) {
			
			myLogger.error("Error occured while validating payee: "+e.getMessage());
			throw new UserException("Problem occured while validating payee"+e.getMessage());
			//e.printStackTrace();
		}
	}
	

	/* ****************************************************************	
	Method Name: insertPayee
	Parameters: payee
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to add new payee to payee_table.
    **************************************************************** */
	@Override
	public void insertPayee(Payee payee) throws UserException {
	
		try{
			con=DBUtil.getConnection();
			String seqsql="SELECT payeeid_seq.nextVal FROM DUAL";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(seqsql);
			if(rs.next())
			payee.setPayeeid(rs.getInt(1));
			String sql="INSERT INTO Payee_Table VALUES(?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setLong(1, payee.getPayeeid());
			pst.setLong(2, payee.getPayeeAccountNo());
			pst.setLong(3, payee.getAccountno());
			pst.setString(4, payee.getNickName());
			
			pst.execute();
			myLogger.info(" Payee inserted sucessfully");
		}
		catch (SQLException e) {
			myLogger.error("Error occured while inserting payee: "+e.getMessage());
			throw new UserException("Problem occured while inserting payee details"+e.getMessage());
			//e.printStackTrace();
		}
				
	}


	/* ****************************************************************	
	Method Name: getAccount
	Parameters: accountno
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to get account from account_master table.
    **************************************************************** */
	@Override
	public AccountMaster getAccount(long accountno) {
		
		AccountMaster account=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM ACCOUNT_MASTER WHERE ACCOUNT_ID =?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			rs.next();
			account=new AccountMaster();
			account.setAccountId(rs.getLong(1));
			account.setCustomerId(rs.getInt(2));
			account.setAccountType(rs.getString(3));
			account.setAccountBalance(rs.getDouble(4));
			account.setOpenDate(rs.getDate(5));
			
			System.out.println(account);
			myLogger.info(" Getting account details of  "+accountno);
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while getting Account: "+e.getMessage());
			throw new UserException("Problem occured while getting account details"+e.getMessage());
			//e.printStackTrace();
		}
		return account;
		
		
			}

	

	/* ****************************************************************	
	Method Name: isCheckBookRequestExist
	Parameters: accountno
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to check if cheque book request has 
    already been made.
    **************************************************************** */
	@Override
	public int isCheckBookRequestExist(Long accountno) throws UserException {

		int requestid=0;
		
		try
		{
			con = DBUtil.getConnection();
			String select = "select * from SERVICE_TRACKER where ACCOUNT_ID=?";
			PreparedStatement pst = con.prepareStatement(select);
			pst.setLong(1, accountno);
			ResultSet res = pst.executeQuery();
			System.out.println(res);
			while(res.next()){
				 requestid=res.getInt(1);
				
			}
			myLogger.info(" Checking checkbook request exist ");	
				
		} 
		catch(SQLException e)
		{
			throw new UserException(e.getMessage());
		}
		catch (Exception e) 
		{
			myLogger.error("Error occured while Checking cheque book request: "+e.getMessage());
			throw new UserException(e.getMessage());
		}
		System.out.println("Request id;"+requestid);
		return requestid;
	}

	/* ****************************************************************	
	Method Name: getRequestedServiceList
	Parameters: requestid
    Author:Group 5
    Date:23/3/2017
    Method Description: Method to get service tracking record.
    **************************************************************** */
	@Override
	public ServiceTracker getRequestedServiceList(int requestid)
			throws UserException {

		ServiceTracker serviceTrack=null;
				try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Service_Tracker WHERE SERVICE_ID=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, requestid);
			ResultSet rs=pst.executeQuery();
			System.out.println(rs);
			while(rs.next())
				{
				serviceTrack=new ServiceTracker();
					serviceTrack.setService_ID(requestid);
					serviceTrack.setService_Description(rs.getString(2));
					serviceTrack.setAccount_ID(rs.getLong(3));
					serviceTrack.setService_Raised_Date(rs.getDate(4));
					serviceTrack.setService_Status(rs.getString(5));
					
				}
			
			
			System.out.println(serviceTrack);		
			myLogger.info(" Getting service tracker details ");
		} 
		catch (SQLException e) {
			
			myLogger.error("Error occured while getting service details: "+e.getMessage());
			throw new UserException("Problem occured while getting service details"+e.getMessage());
			//e.printStackTrace();
		}
		return serviceTrack;
		
	}


	

	
}
